# ID3a2024
Projekt na zajęcia z Inżynierii oprogramowania

## Opis projektu
Tworzymy stronę internetową z planem lekcji UBB, która będzie aktualizowana przez workera. Użytkownik będzie mógł przeglądać plany zajęć, dodawać je do ulubionych oraz przeglądać je w czytelny sposób.

## Wymagania niefunkcjonalne
- Wysoka wydajność
- Skalowalność
- Użyteczność

## Wymagania funkcjonalne
- Użytkownik może przeglądać plany zajęć
- Plan lekcji jest aktualizowany przez działającego w tle workera
- Plan jest przechowywany w formacie json
- Możliwość dodawania planów do ulubionych
- Nowoczesny i responsywny design

## Potencjalne ryzyka
- Brak doświadczenia pracy w grupie
- Nieznajomość niektórych technologii
- Potencjalne konflikty związane z wspólną pracą

## Lista ogólnych zadań do wykonania
- Webscrapping strony z planem UBB
- Przygotowanie API w języku go
- Implementacja backend w SvelteKit
- Przygotowanie widoków
- Integracja Api z backendem
- Wdrożenie logiki do widoków

## Diagram aplikacji
![Diagram](images/diagram.png)