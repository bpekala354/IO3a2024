package routes

import (
	planubb "github.com/ctxx3/id3a2024/fetch/plan_ubb"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

func Setup(app *fiber.App) {

	app.Use(cors.New(cors.Config{
		AllowOrigins: "*", // You can specify allowed origins here
		AllowMethods: "GET,POST,HEAD,PUT,DELETE,PATCH,OPTIONS",
		AllowHeaders: "Origin, Content-Type, Accept",
	}))

	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("Hello, World!")
	})
	app.Get("/plan/:id", func(c *fiber.Ctx) error {
		id := c.Params("id")
		return c.SendString("Plan UBB with ID: " + id)
	})
	app.Get("/fetchInfo", func(c *fiber.Ctx) error {
		planubb.UpdateAll()
		return c.SendString("success: true")
	})
	app.Get("/fetchAllGroups", func(c *fiber.Ctx) error {
		planubb.FetchGroups()
		return c.SendString("success: true")
		//text := planubb.GetKeys(fetch.ReadFromFileJSON("data/groups.json"), "")
		//return c.SendString(strings.Join(text, ", "))
	})

	app.Get("/getGroup/:id", func(c *fiber.Ctx) error {
		id := c.Params("id")
		filePath := "data/groups/" + id + ".json"
		return c.SendFile(filePath)
	})

	app.Get("/getLastUpdate", func(c *fiber.Ctx) error {
		return c.SendFile("data/last-update.json")
	})
	app.Get("/getGroups", func(c *fiber.Ctx) error {
		return c.SendFile("data/groups.json")
	})
	app.Get("/getRooms", func(c *fiber.Ctx) error {
		return c.SendFile("data/rooms.json")
	})
	app.Get("/getRoomsInfo", func(c *fiber.Ctx) error {
		return c.SendFile("data/rooms-info.json")
	})
	app.Get("/getLecturers", func(c *fiber.Ctx) error {
		return c.SendFile("data/lecturers.json")
	})
}
