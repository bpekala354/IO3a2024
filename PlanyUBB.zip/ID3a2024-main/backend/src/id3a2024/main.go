package main

import (
	"fmt"

	"github.com/ctxx3/id3a2024/routes"
	"github.com/gofiber/fiber/v2"
)

func main() {
	//planubb.UpdateAll()
	//data := fetch.ReadFromFileJSON("data/groups.json")
	//printKeys(data, "")
	app := fiber.New()

	routes.Setup(app)
	//planubb.GetKeys(fetch.ReadFromFileJSON("data/groups.json"), "")
	app.Listen(":3000")
}

func printKeys(data map[string]interface{}, indent string) {
	for key, value := range data {
		//fmt.Print(indent, key)
		if str, ok := value.(string); ok {
			fmt.Println("[" + str + "] " + key)
		} else {
			//fmt.Println()
			if nestedMap, ok := value.(map[string]interface{}); ok {
				printKeys(nestedMap, indent)
			}
		}
	}
}

func getKeys(data map[string]interface{}, indent string) []string {
	keys := make([]string, 0)
	for _, value := range data {
		if str, ok := value.(string); ok {
			fmt.Printf("[" + str + "] ")
			keys = append(keys, str)
		} else {
			//fmt.Println()
			if nestedMap, ok := value.(map[string]interface{}); ok {
				getKeys(nestedMap, indent)
			}
		}
	}
	return keys
}
