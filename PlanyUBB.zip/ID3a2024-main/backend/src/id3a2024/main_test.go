package main

import (
	"reflect"
	"testing"
)

func TestGetKeys(t *testing.T) {
	tests := []struct {
		name     string
		data     map[string]interface{}
		expected []string
	}{
		{
			name: "flat map",
			data: map[string]interface{}{
				"key1": "value1",
				"key2": "value2",
			},
			expected: []string{"value1", "value2"},
		},
		{
			name:     "empty map",
			data:     map[string]interface{}{},
			expected: []string{},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := getKeys(tt.data, "")
			if !reflect.DeepEqual(result, tt.expected) {
				t.Errorf("expected %v, got %v", tt.expected, result)
			}
		})
	}
}
