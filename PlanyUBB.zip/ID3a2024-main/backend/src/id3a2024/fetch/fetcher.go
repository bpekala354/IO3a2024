package fetch

import (
	"encoding/json"
	"os"
	"path/filepath"

	"github.com/gofiber/fiber/v2"
)

func Get(url string) ([]byte, error) {
	request := fiber.Get(url)
	_, data, errs := request.Bytes()
	if len(errs) > 0 {
		return nil, errs[0]
	}
	return data, nil
}

func SaveToFile(url, filename string) error {
	data, err := Get(url)
	if err != nil {
		return err
	}

	err = os.MkdirAll(filepath.Dir(filename), os.ModePerm)
	if err != nil {
		return err
	}

	err = os.WriteFile(filename, data, os.ModePerm)
	if err != nil {
		return err
	}
	return nil
}

func ReadFromFile(filename string) []byte {
	data, err := os.ReadFile(filename)
	if err != nil {
		panic(err)
	}
	return data
}

func ReadFromFileJSON(filename string) map[string]interface{} {
	data := ReadFromFile(filename)
	var result map[string]interface{}
	err := json.Unmarshal(data, &result)
	if err != nil {
		panic(err)
	}
	return result
}
