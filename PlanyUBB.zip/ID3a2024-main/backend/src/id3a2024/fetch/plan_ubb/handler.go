package planubb

import (
	"fmt"
	"regexp"
	"sync"
	"time"

	"github.com/ctxx3/id3a2024/fetch"
)

const (
	api   = "https://api.mganczarczyk.pl/ubb/timetable"
	apiv4 = "https://v4.api.mganczarczyk.pl/v4/UBB"
	path  = "data"
)

type Fetcher struct {
	api string
}

func (f *Fetcher) Get(endpoint, filename string) bool {
	url := f.api + endpoint
	filepath := path + filename
	//fmt.Println("Fetching", url, "to", filepath)
	err := fetch.SaveToFile(url, filepath)
	return err == nil
}

func UpdateAll() {
	(&Fetcher{api: api}).Get("/last-update", "/last-update.json")
	(&Fetcher{api: api}).Get("/path/groups", "/groups.json")
	(&Fetcher{api: api}).Get("/path/rooms", "/rooms.json")
	(&Fetcher{api: api}).Get("/rooms-info", "/rooms-info.json")
	(&Fetcher{api: api}).Get("/path/lecturers", "/lecturers.json")
}

func FetchGroup(group string, wg *sync.WaitGroup, successCount *int, mu *sync.Mutex) bool {
	defer wg.Done()
	success := (&Fetcher{api: apiv4}).Get("/"+group, "/groups/"+group+".json")
	if success {
		fmt.Println("Fetched group: ", group)
		mu.Lock()
		*successCount++
		mu.Unlock()
	} else {
		fmt.Println("Failed to fetch group: ", group)
	}
	return success
}

func FetchGroups() {
	data := fetch.ReadFromFileJSON("data/groups.json")
	keys := GetKeys(data, "")
	var wg sync.WaitGroup
	var successCount int
	var mu sync.Mutex
	totalCount := len(keys)

	batchSize := 100
	for i := 0; i < totalCount; i += batchSize {
		end := i + batchSize
		if end > totalCount {
			end = totalCount
		}
		batch := keys[i:end]

		for _, key := range batch {
			wg.Add(1)
			go FetchGroup(key, &wg, &successCount, &mu)
		}

		wg.Wait()
		fmt.Printf("Successfully fetched %d out of %d groups so far\n", successCount, totalCount)
		if end < totalCount {
			time.Sleep(32 * time.Second)
		}
	}

	fmt.Printf("Successfully fetched %d out of %d groups\n", successCount, totalCount)
}

func GetKeys(data map[string]interface{}, indent string) []string {
	keys := make([]string, 0)
	re := regexp.MustCompile(`^\d+$`)

	for _, value := range data {
		if str, ok := value.(string); ok {
			if re.MatchString(str) {
				keys = append(keys, str)
			}
		} else {
			if nestedMap, ok := value.(map[string]interface{}); ok {
				nestedKeys := GetKeys(nestedMap, indent)
				keys = append(keys, nestedKeys...)
			}
		}
	}
	return keys
}
