<script>
    import { onMount } from 'svelte';
    let wydzialy = ['Wydział 1', 'Wydział 2', 'Wydział 3', 'Wydział 4', 'Wydział 5'];
    let tryby = ['Stacjonarne', 'Niestacjonarne Wieczorowe', 'Niestacjonarne Zaoczne'];
    let kierunki = {
      'Stacjonarne': ['Kierunek A', 'Kierunek B', 'Kierunek C', 'Kierunek D'],
      'Niestacjonarne Wieczorowe': ['Kierunek E', 'Kierunek F', 'Kierunek G', 'Kierunek H'],
      'Niestacjonarne Zaoczne': ['Kierunek I', 'Kierunek J', 'Kierunek K', 'Kierunek L']
    };
    let stopnie = ['I stopień', 'II stopień'];
    let semestry = [1, 2, 3, 4, 5, 6, 7, 8];
    let grupy = ['1a', '1b', '2a', '2b', '3a', '3b'];
    let dniTygodnia = ['Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota', 'Niedziela'];
    
    let selectedWydzial = '';
    let selectedTryb = '';
    let selectedKierunek = '';
    let selectedStopien = '';
    let selectedSemestr = '';
    let selectedGrupa = '';
    let planZajec = {};
  
    function fetchPlan() {
      // Symulacja pobrania danych planu lekcji
      planZajec = {
        'Poniedziałek': [{ godziny: '08:00 - 09:30', przedmiot: 'Matematyka', prowadzacy: 'Dr. Kowalski', sala: '101' }],
        'Wtorek': [{ godziny: '10:00 - 11:30', przedmiot: 'Fizyka', prowadzacy: 'Dr. Nowak', sala: '102' }],
        'Środa': [],
        'Czwartek': [{ godziny: '12:00 - 13:30', przedmiot: 'Informatyka', prowadzacy: 'Dr. Wiśniewski', sala: '103' }],
        'Piątek': [{ godziny: '14:00 - 15:30', przedmiot: 'Chemia', prowadzacy: 'Dr. Lewandowski', sala: '104' }],
        'Sobota': [{ godziny: '16:00 - 17:30', przedmiot: 'Biologia', prowadzacy: 'Dr. Zieliński', sala: '105' }],
        'Niedziela': []
      };
    }
  </script>
  
    <div class="p-4">
      <h1 class="text-2xl font-bold mb-4">Wybierz opcje planu lekcji</h1>
      <select bind:value={selectedWydzial} class="block w-full p-2 mb-4 border rounded">
        <option value="">Wybierz wydział</option>
        {#each wydzialy as wydzial}
          <option value={wydzial}>{wydzial}</option>
        {/each}
      </select>
      
      {#if selectedWydzial}
        <select bind:value={selectedTryb} class="block w-full p-2 mb-4 border rounded">
          <option value="">Wybierz tryb studiów</option>
          {#each tryby as tryb}
            <option value={tryb}>{tryb}</option>
          {/each}
        </select>
      {/if}
      
      {#if selectedTryb}
        <select bind:value={selectedKierunek} class="block w-full p-2 mb-4 border rounded">
          <option value="">Wybierz kierunek</option>
          {#each kierunki[selectedTryb] as kierunek}
            <option value={kierunek}>{kierunek}</option>
          {/each}
        </select>
      {/if}
      
      {#if selectedKierunek}
        <select bind:value={selectedStopien} class="block w-full p-2 mb-4 border rounded">
          <option value="">Wybierz stopień studiów</option>
          {#each stopnie as stopien}
            <option value={stopien}>{stopien}</option>
          {/each}
        </select>
      {/if}
    
      {#if selectedStopien}
        <select bind:value={selectedSemestr} class="block w-full p-2 mb-4 border rounded">
          <option value="">Wybierz semestr</option>
          {#each semestry as semestr}
            <option value={semestr}>{semestr}</option>
          {/each}
        </select>
      {/if}
    
      {#if selectedSemestr}
        <select bind:value={selectedGrupa} class="block w-full p-2 mb-4 border rounded">
          <option value="">Wybierz grupę</option>
          {#each grupy as grupa}
            <option value={grupa}>{grupa}</option>
          {/each}
        </select>
      {/if}
    
      {#if selectedGrupa}
        <button on:click={fetchPlan} class="bg-blue-500 text-white p-2 rounded">Pokaż plan</button>
      {/if}
    </div>
    
    {#if Object.keys(planZajec).length}
      <div class="mt-8">
        <h2 class="text-red-500 text-xl font-bold mb-4">Plan zajęć</h2> 
        {#each dniTygodnia as dzien}
          <h3 class="text-lg font-semibold mb-2">{dzien}</h3>
          {#if planZajec[dzien]?.length > 0}
            <ul class="list-disc pl-5 mb-4">
              {#each planZajec[dzien] as zajecia}
                <li class="mb-2">{zajecia.godziny} - {zajecia.przedmiot} ({zajecia.prowadzacy}) w sali {zajecia.sala}</li>
              {/each}
            </ul>
          {:else}
            <p class="text-gray-500">Brak zajęć</p>
          {/if}
        {/each}
      </div>
    {/if}
  
