export async function fetchGroup(id: number) {
    try {
        const response = await fetch('http://localhost:3000/getGroup/'+id, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
        });
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
}