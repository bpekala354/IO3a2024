  <script lang="ts">
  import { onMount } from "svelte";
  import { fetchSchedule } from "./fetchSchedule";

  type Schedule = { day: string; subject: string; time: string };
  type Schedules = { [key: string]: { [mode: string]: { [course: string]: Schedule[] } } };

  let schedules: Schedules = {};
  let selectedDepartment: keyof Schedules = "Science";
  let selectedMode: string = "Full-time";
  let selectedCourse: string = "Undergraduate";
  let schedule: Schedule[] = [];

  onMount(async () => {
    try {
      schedules = await fetchSchedule();
      console.log(schedules)
      updateSchedule();
    } catch (error) {
      console.error("Error fetching schedule:", error);
    }
  });

  function updateSchedule() {
    if (
      schedules[selectedDepartment] &&
      schedules[selectedDepartment][selectedMode] &&
      schedules[selectedDepartment][selectedMode][selectedCourse]
    ) {
      schedule = schedules[selectedDepartment][selectedMode][selectedCourse];
    } else {
      schedule = [];
    }
  }

  function handleDepartmentChange(event: Event) {
    selectedDepartment = (event.target as HTMLSelectElement)?.value as keyof Schedules;
    updateSchedule();
  }

  function handleModeChange(event: Event) {
    selectedMode = (event.target as HTMLSelectElement)?.value;
    updateSchedule();
  }

  function handleCourseChange(event: Event) {
    selectedCourse = (event.target as HTMLSelectElement)?.value;
    updateSchedule();
  }
</script>

<main>
  <h1>School Schedule</h1>
  <label for="department">Select faculty of studies :</label>
  <select id="department" on:change={handleDepartmentChange}>
    {#each Object.keys(schedules) as department}
      <option value={department}>{department}</option>
    {/each}
  </select>

  <label for="mode">Select Mode:</label>
  <select id="mode" on:change={handleModeChange}>
    {#each Object.keys(schedules[selectedDepartment] || {}) as mode}
      <option value={mode}>{mode}</option>
    {/each}
  </select>

  <label for="course">Select field of study:</label>
  <select id="course" on:change={handleCourseChange}>
    {#each Object.keys(schedules[selectedDepartment]?.[selectedMode] || {}) as course}
      <option value={course}>{course}</option>
    {/each}
  </select>

  <div class="schedule">
    {#each schedule as lesson}
      <div class="card">
        <p><strong>Day:</strong> {lesson.day}</p>
        <p><strong>Subject:</strong> {lesson.subject}</p>
        <p><strong>Time:</strong> {lesson.time}</p>
      </div>
    {/each}
  </div>
</main>

<style>
  main {
    padding: 2rem;
    font-family: Arial, sans-serif;
  }
  .schedule {
    display: flex;
    flex-direction: column;
    gap: 2rem;
  }
  .card {
    border: 1px solid #ddd;
    padding: 1rem;
    border-radius: 8px;
    background-color: #f9f9f9;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  .card p {
    margin: 0.25rem 0;
  }
</style>
