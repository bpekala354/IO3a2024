<script lang="ts">
	import '../app.css';
	let { children } = $props();
</script>

<svelte:head>
	<title>Plan UBB</title>
</svelte:head>

{@render children()}
