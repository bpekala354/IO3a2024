import { env } from "$env/dynamic/private";

export default class PlanUBBController {
    static async getPlanUBB() {
        const response = await fetch(env.API_URL + "/plan-ubb");
        const data = await response.json();
        return data;
    }
    
    static async getPlanUBBByCode(code) {
        const response = await fetch(;
        const data = await response.json();
        return data;
    }
}
